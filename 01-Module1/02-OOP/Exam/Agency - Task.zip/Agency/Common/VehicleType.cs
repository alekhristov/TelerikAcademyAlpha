﻿namespace Agency.Common
{
    public enum VehicleType
    {
        Land,
        Air,
        Sea
    }
}
