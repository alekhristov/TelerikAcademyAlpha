﻿namespace Agency.Models.Vehicles.Contracts
{
    public interface IAirplane
    {
        bool HasFreeFood { get; }
    }
}