﻿namespace Agency.Core.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
